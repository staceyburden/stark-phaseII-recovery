"""Canonicalize spreadsheet XML while retaining original drawings/charts and formula caches."""
from pathlib import Path
from copy import deepcopy
from lxml import etree as E
import tempfile,zipfile,re,json
import openpyxl as x
from openpyxl.worksheet._writer import WorksheetWriter
from openpyxl.workbook._writer import WorkbookWriter
from openpyxl.styles.stylesheet import write_stylesheet
from openpyxl.xml.functions import tostring
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';q=lambda n:'{'+N+'}'+n
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships';rid='{'+R+'}id'
def normalize(source,output):
 source=Path(source);output=Path(output)
 with zipfile.ZipFile(source) as z:parts={n:z.read(n) for n in z.namelist()}
 wb=x.load_workbook(source);oldbook=E.fromstring(parts['xl/workbook.xml']);oldids={s.get('name'):s.get(rid) for s in oldbook.find(q('sheets'))};changed=[];caches=0;filters_removed=0;tables_removed=0
 with tempfile.TemporaryDirectory(prefix='stark-normalize-') as tmp:
  for i,sh in enumerate(wb.worksheets,1):
   name=f'xl/worksheets/sheet{i}.xml';old=E.fromstring(parts[name]);oldcells={c.get('r'):c for c in old.iter(q('c'))}
   if sh.tables:
    tablelist=list(sh.tables.values())
    if len(tablelist)!=1:raise ValueError('This compatibility repair expects one maintained input/report range per sheet.')
    if sh.auto_filter.ref is not None:filters_removed+=1
    sh.auto_filter=deepcopy(tablelist[0].autoFilter)
    tables_removed+=len(tablelist)
    sh._tables.clear()
   if i<=3:sh.auto_filter.ref=['A8:AE218','A10:AE430','A7:O217'][i-1]
   writer=WorksheetWriter(sh,str(Path(tmp)/f'sheet{i}.xml'));writer.write();root=E.parse(writer.out).getroot()
   for c in root.iter(q('c')):
    f=c.find(q('f'))
    if f is None:continue
    original=oldcells[c.get('r')];of=original.find(q('f'));assert of is not None and f.text==of.text,(name,c.get('r'))
    for v in c.findall(q('v')):c.remove(v)
    v=original.find(q('v'))
    if v is not None:c.append(deepcopy(v));caches+=1
    if original.get('t') is not None:c.set('t',original.get('t'))
    else:c.attrib.pop('t',None)
   # Preserve existing relationship targets/IDs. No charts or drawing files are reserialized.
   for tag in ['drawing','legacyDrawing','legacyDrawingHF','picture']:
    new=root.find(q(tag));previous=old.find(q(tag))
    if new is not None and previous is not None:new.set(rid,previous.get(rid))
   nt=root.find(q('tableParts'));ot=old.find(q('tableParts'))
   if nt is not None and ot is not None:
    assert len(nt)==len(ot)
    for a,b in zip(nt,ot):a.set(rid,b.get(rid))
   ext=old.find(q('extLst'))
   if ext is not None:root.append(deepcopy(ext))
   parts[name]=E.tostring(root,encoding='UTF-8',xml_declaration=True)
   for table in sh.tables.values():parts[f'xl/tables/table{table.id}.xml']=tostring(table.to_tree())
   changed.append(name)
  book=E.fromstring(WorkbookWriter(wb).write())
  for s in book.find(q('sheets')):s.set(rid,oldids[s.get('name')])
  parts['xl/workbook.xml']=E.tostring(book,encoding='UTF-8',xml_declaration=True);parts['xl/styles.xml']=tostring(write_stylesheet(wb))
 # Remove the rejected Table parts and their relationships/content-type entries.
 for n in list(parts):
  if n.startswith('xl/tables/'):parts.pop(n)
 for n in list(parts):
  if not n.startswith('xl/worksheets/_rels/') or not n.endswith('.rels'):continue
  rel=E.fromstring(parts[n])
  for child in list(rel):
   if child.get('Type','').endswith('/table'):rel.remove(child)
  if len(rel):parts[n]=E.tostring(rel,encoding='UTF-8',xml_declaration=True)
  else:parts.pop(n)
 ct=E.fromstring(parts['[Content_Types].xml'])
 for child in list(ct):
  if child.get('PartName','').startswith('/xl/tables/'):ct.remove(child)
 parts['[Content_Types].xml']=E.tostring(ct,encoding='UTF-8',xml_declaration=True)
 # Canonical worksheet serialization uses inline strings. Remove the now-unreferenced old SST.
 sharedrefs=sum(len(E.fromstring(b).findall('.//'+q('c')+'[@t="s"]')) for n,b in parts.items() if re.fullmatch(r'xl/worksheets/sheet\d+.xml',n))
 if sharedrefs==0:
  parts.pop('xl/sharedStrings.xml',None)
  rel=E.fromstring(parts['xl/_rels/workbook.xml.rels'])
  for child in list(rel):
   if child.get('Type','').endswith('/sharedStrings'):rel.remove(child)
  parts['xl/_rels/workbook.xml.rels']=E.tostring(rel,encoding='UTF-8',xml_declaration=True)
  ct=E.fromstring(parts['[Content_Types].xml'])
  for child in list(ct):
   if child.get('PartName')=='/xl/sharedStrings.xml':ct.remove(child)
  parts['[Content_Types].xml']=E.tostring(ct,encoding='UTF-8',xml_declaration=True)
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)
 return {'formula_caches_preserved':caches,'worksheets_normalized':len(changed),'conflicting_filter_pairs_resolved':filters_removed,'charts_reserialized':0,'rejected_table_objects_removed':tables_removed,'maintained_filter_ranges':3}
if __name__=='__main__':
 import sys
 print(json.dumps(normalize(sys.argv[1],sys.argv[2]),indent=2))
