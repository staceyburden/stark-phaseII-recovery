#!/usr/bin/env python3
"""Refresh the maintained Stark workbook without overwriting its input or losing Excel extensions."""
from pathlib import Path
from copy import deepcopy as cp
from lxml import etree as E
import openpyxl as x
import warnings
# Original Excel extensions are preserved through direct package/XML editing below.
warnings.filterwarnings("ignore", message="Data Validation extension is not supported and will be removed", category=UserWarning, module="openpyxl")
import argparse,datetime as dt,json,re,shutil,subprocess,tempfile,zipfile,time
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';q=lambda n:'{'+NS+'}'+n
CN='http://schemas.openxmlformats.org/drawingml/2006/chart';cq=lambda n:'{'+CN+'}'+n
AN='http://schemas.openxmlformats.org/drawingml/2006/main';aq=lambda n:'{'+AN+'}'+n
CONTROL='05 CONTROL & GUIDE';CAP=210;LOTS=420

def loadparts(path):
 with zipfile.ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
def saveparts(parts,path):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)
def scalar(cell,value):
 for child in list(cell):cell.remove(child)
 cell.attrib.pop('t',None)
 if isinstance(value,str):cell.set('t','inlineStr');E.SubElement(E.SubElement(cell,q('is')),q('t')).text=value
 elif value is not None:E.SubElement(cell,q('v')).text=str(x.utils.datetime.to_excel(value) if isinstance(value,(dt.date,dt.datetime)) else value)
def cells(root):return {c.get('r'):c for c in root.iter(q('c'))}
def ensure(root,addr):
 found=root.find(f'.//{q("c")}[@r="{addr}"]')
 if found is not None:return found
 sd=root.find(q('sheetData'));r=int(re.search(r'\d+',addr)[0]);row=sd.find(f'{q("row")}[@r="{r}"]')
 if row is None:row=E.SubElement(sd,q('row'),r=str(r))
 c=E.SubElement(row,q('c'),r=addr)
 sd[:]=sorted(sd,key=lambda v:int(v.get('r')))
 row[:]=sorted(row,key=lambda v:x.utils.cell.column_index_from_string(re.match(r'[A-Z]+',v.get('r'))[0]))
 return c

def whole_date(value,label):
 if isinstance(value,dt.datetime):
  if value.time()!=dt.time():raise ValueError(f'{label} must have no time component.')
  return value
 if isinstance(value,dt.date):return dt.datetime.combine(value,dt.time())
 if isinstance(value,(int,float)) and not isinstance(value,bool) and value==int(value) and 0<value<=2958465:return x.utils.datetime.from_excel(value)
 raise ValueError(f'{label} must be a valid whole Excel date.')
def input_controls(book):
 for row in book.worksheets[0].iter_rows(min_row=219,max_col=24):
  if any(v.value is not None and v.value!="" for v in row):raise ValueError('Source data exceeds 210 PO lines; do not enter below row 218.')
 for row in book.worksheets[1].iter_rows(min_row=431,min_col=10,max_col=25):
  if any(v.value is not None and v.value!="" for v in row):raise ValueError('Plan input exceeds 420 recovery lots; do not enter below row 430.')
 c=book[CONTROL];asof=whole_date(c['B4'].value,'AS OF');start=whole_date(c['B6'].value,'Chart start');baseline=whole_date(book.worksheets[0]['AF5'].value,'Frozen baseline');transit=c['B5'].value;page=c['B8'].value
 if not isinstance(transit,(int,float)) or isinstance(transit,bool) or int(transit)!=transit or not 0<=transit<=365:raise ValueError('Transit must be a whole number from 0 to 365.')
 if not isinstance(page,(int,float)) or isinstance(page,bool) or page!=int(page) or page<1:raise ValueError('Chart page must be a positive whole number.')
 if start.weekday()!=0:raise ValueError('Chart start must be a Monday.')
 if asof<baseline:raise ValueError('AS OF must not precede the frozen baseline.')
 if not baseline<=start<=baseline+dt.timedelta(days=305):raise ValueError('Chart start must stay inside the supported one-year cycle.')
 return asof,start,baseline,int(page)

def initialize_cycle(parts,book):
 s=book.worksheets[0];control=book[CONTROL];baseline=whole_date(control['B9'].value,'Proposed cycle baseline');asof=whole_date(control['B4'].value,'AS OF')
 if asof<baseline:raise ValueError('Set AS OF on/after the proposed new baseline.')
 records=[];seen=set()
 def keyval(v):return str(int(v)) if isinstance(v,float) and v.is_integer() else str(v)
 for r in range(9,219):
  vals=[s.cell(r,c).value for c in range(1,25)]
  if all(v is None or v=='' for v in vals):continue
  if any(s.cell(r,c).data_type=='f' for c in range(1,25)):raise ValueError(f'Source row {r}: paste values, not formulas, for a new cycle.')
  if any(v is None or not str(v).strip() for v in vals[:5]):raise ValueError(f'Source row {r}: incomplete PO identity.')
  if not isinstance(vals[5],(int,float)) or isinstance(vals[5],bool) or vals[5]<=0:raise ValueError(f'Source row {r}: open quantity must be positive.')
  if not str(vals[10] or '').strip():raise ValueError(f'Source row {r}: supplier name is required.')
  if not str(vals[17] or '').strip():raise ValueError(f'Source row {r}: UOM is required.')
  whole_date(vals[8],f'Source row {r} expedited need date')
  key='|'.join(keyval(vals[c]) for c in [0,2,3,4,1])
  if key.casefold() in seen:raise ValueError(f'Source row {r}: duplicate PO-line key.')
  seen.add(key.casefold());records.append((r,vals,key))
 if not records:raise ValueError('No source records were supplied for the new cycle.')
 if len({str(vals[0]).strip().casefold() for _,vals,_ in records})!=1:raise ValueError('Use ONE supplier per recovery cycle/workbook.')
 units={}
 for _,vals,_ in records:
  part=str(vals[1]).casefold();unit=str(vals[17]).strip().upper()
  if part in units and units[part]!=unit:raise ValueError(f'Part {vals[1]} has inconsistent units.')
  units[part]=unit
 r1=E.fromstring(parts['xl/worksheets/sheet1.xml']);r2=E.fromstring(parts['xl/worksheets/sheet2.xml']);r5=E.fromstring(parts['xl/worksheets/sheet5.xml'])
 for r in range(9,219):
  for col in range(32,58):scalar(ensure(r1,x.utils.cell.get_column_letter(col)+str(r)),None)
 for r,vals,key in records:
  for col,v in enumerate(vals,32):scalar(ensure(r1,x.utils.cell.get_column_letter(col)+str(r)),v)
  scalar(ensure(r1,f'BD{r}'),key);scalar(ensure(r1,f'BE{r}'),vals[5])
 scalar(ensure(r1,'AF5'),baseline)
 for r in range(11,431):
  for col in ['M','N','O','Q','R','S','T','V','W','X','Y']+(['J'] if r>=221 else []):scalar(ensure(r2,f'{col}{r}'),None)
 scalar(ensure(r5,'B8'),1)
 scalar(ensure(r5,'B35'),dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M UTC'))
 scalar(ensure(r1,'K5'),'LIVE CYCLE — STARK INITIALIZED; review before release')
 if 'START HERE' in book.sheetnames:
  guide=E.fromstring(parts['xl/worksheets/sheet6.xml'])
  scalar(ensure(guide,'A4'),'LIVE CYCLE — new frozen baseline captured by Stark. Review data exceptions, late-plan actions, owners and refresh coverage before release. Archive each sent/returned version.')
  parts['xl/worksheets/sheet6.xml']=E.tostring(guide,encoding='UTF-8',xml_declaration=True)
 for idx,root in [(1,r1),(2,r2),(5,r5)]:parts[f'xl/worksheets/sheet{idx}.xml']=E.tostring(root,encoding='UTF-8',xml_declaration=True)
 return len(records)

def clear_caches(parts):
 for n in list(parts):
  if not re.fullmatch(r'xl/worksheets/sheet\d+.xml',n):continue
  root=E.fromstring(parts[n])
  for cell in root.iter(q('c')):
   if cell.find(q('f')) is not None:
    for v in cell.findall(q('v')):cell.remove(v)
    cell.attrib.pop('t',None)
  parts[n]=E.tostring(root,encoding='UTF-8',xml_declaration=True)

def calculate(inputfile,workdir,soffice,profile):
 dest=workdir/'calculated';dest.mkdir();start=time.perf_counter()
 cmd=[soffice,f'-env:UserInstallation={profile.as_uri()}','--headless','--convert-to','xlsx','--outdir',str(dest),str(inputfile)]
 proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
 result=dest/inputfile.name
 if proc.returncode or not result.exists():raise RuntimeError('Calculation failed: '+proc.stdout+' '+proc.stderr)
 return result,time.perf_counter()-start

def finish(parts,calculated):
 raw=loadparts(calculated);book=x.load_workbook(calculated,data_only=True);s,b=book.worksheets[0],book.worksheets[2];c=book[CONTROL]
 asof=whole_date(c['B4'].value,'AS OF');start=whole_date(c['B6'].value,'Chart start');end=whole_date(c['B7'].value,'Chart end');base=whole_date(s['AF5'].value,'Frozen baseline')
 page=int(c['B8'].value);pages=int(c['B26'].value)
 if page>pages:raise ValueError(f'Chart page {page} exceeds the {pages} available page(s).')
 if end>base+dt.timedelta(days=365):raise ValueError('Chart end exceeds the one-year supported calculation horizon.')
 dates=[start+dt.timedelta(days=k) for k in range((end-start).days+1) if (start+dt.timedelta(days=k)).weekday() in [0,4]]
 caches={n:cells(E.fromstring(v)) for n,v in raw.items() if re.fullmatch(r'xl/worksheets/sheet\d+.xml',n)}
 for n in caches:
  root=E.fromstring(parts[n])
  for cell in root.iter(q('c')):
   if cell.find(q('f')) is None:continue
   cc=caches[n].get(cell.get('r'))
   if cc is None or cc.find(q('v')) is None:raise ValueError(f'Missing calculation result: {n} {cell.get("r")}')
   for old in cell.findall(q('v')):cell.remove(old)
   cell.set('t',cc.get('t','n'));cell.append(cp(cc.find(q('v'))))
  if n=='xl/worksheets/sheet5.xml':
   scalar(ensure(root,'B33'),c['B32'].value);scalar(ensure(root,'B34'),dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M UTC'))
   cc=ensure(root,'B31');cc.set('t','str');v=cc.find(q('v'));v.text='CURRENT'
  parts[n]=E.tostring(root,encoding='UTF-8',xml_declaration=True)
 def cache_ref(ref,tag):
  formula=ref.find(cq('f')).text;sheet,rg=formula.rsplit('!',1);sheet=sheet.strip("'");rg=rg.replace('$','');selected=book[sheet][rg]
  if not isinstance(selected,tuple):selected=((selected,),)
  vals=[cell for row in selected for cell in row];old=ref.find(cq(tag))
  if old is not None:ref.remove(old)
  ca=E.SubElement(ref,cq(tag))
  if tag=='numCache':E.SubElement(ca,cq('formatCode')).text='General'
  E.SubElement(ca,cq('ptCount'),val=str(len(vals)))
  for k,cell in enumerate(vals):
   value=cell.value
   if value is None or (tag=='numCache' and cell.data_type=='e'):continue
   if tag=='numCache':value=caches['xl/worksheets/sheet3.xml'][cell.coordinate].find(q('v')).text
   E.SubElement(E.SubElement(ca,cq('pt'),idx=str(k)),cq('v')).text=str(value)
 for n in list(parts):
  m=re.fullmatch(r'xl/charts/chart(\d+).xml',n)
  if not m:continue
  i=int(m[1])-1;row=8+i;root=E.fromstring(parts[n]);part=b[f'DQ{row}'].value;title=root.find('.//'+cq('title'));tx=title.find(cq('tx'))
  for child in list(tx):tx.remove(child)
  rich=E.SubElement(tx,cq('rich'));E.SubElement(rich,aq('bodyPr'));E.SubElement(rich,aq('lstStyle'));p=E.SubElement(rich,aq('p'))
  text=b[f'DX{row}'].value or 'UNUSED CHART SLOT';split=text.split(' | ',1) if part else [text]
  for j,value in enumerate(split):
   value=(' | '+value) if j else value;run=E.SubElement(p,aq('r'));rp=E.SubElement(run,aq('rPr'),sz='1300',b='1',lang='en-US');E.SubElement(E.SubElement(rp,aq('solidFill')),aq('srgbClr'),val='FF0000' if part and j==0 else 'FFFFFF');E.SubElement(run,aq('t')).text=value
  E.SubElement(p,aq('endParaRPr'),lang='en-US')
  axes=[ax for ax in root.findall('.//'+cq('valAx')) if ax.find(cq('axPos')).get('val')=='b'];scale=axes[0].find(cq('scaling'))
  for name,value in [('min',start),('max',end)]:scale.find(cq(name)).set('val',str(int(x.utils.datetime.to_excel(value))))
  series=root.findall('.//'+cq('ser'));labelser=series[4];labels=labelser.find(cq('dLbls'));template=cp(labels.find(cq('dLbl')))
  for old in labels.findall(cq('dLbl')):labels.remove(old)
  for k,date in enumerate(dates):
   label=cp(template);label.find(cq('idx')).set('val',str(k));texts=label.findall('.//'+aq('t'));texts[0].text=date.strftime('%a');texts[1].text=f'{date.month}/{date.day}';labels.insert(k,label)
  for typ,column in [('xVal','HE'),('yVal',x.utils.cell.get_column_letter(214+i))]:labelser.find(cq(typ)+'/'+cq('numRef')+'/'+cq('f')).text=f"'03 BURNDOWN DATA'!${column}$8:${column}${7+len(dates)}"
  for ser in series:
   label=ser.find(cq('tx')+'/'+cq('v'))
   if label is not None and label.text=='Stark Need Date':
    for e in ser.findall(cq('errBars')):ser.remove(e)
    ser.find(cq('spPr')+'/'+aq('ln')).set('w','6350')
  for typ,ctag in [('numRef','numCache'),('strRef','strCache')]:
   for ref in root.iter(cq(typ)):cache_ref(ref,ctag)
  parts[n]=E.tostring(root,encoding='UTF-8',xml_declaration=True)
 # Update print areas to populated records; keep repeated headers and two-chart overview page breaks.
 wb=E.fromstring(parts['xl/workbook.xml']);names=wb.find(q('definedNames'));lastsource=max([r for r in range(9,219) if s[f'BD{r}'].value] or [9]);plan=book.worksheets[1];lastauto=max([r for r in range(11,221) if plan[f'J{r}'].value] or [11]);lastsplit=max([r for r in range(221,431) if plan[f'J{r}'].value] or [0]);lastreport=max([r for r in range(8,218) if b[f'A{r}'].value] or [8])
 areas={0:f"'01 OOR PASTE'!$A$1:$X${lastsource}",1:f"'02 Supplier Recovery Plan'!$A$1:$AE${lastauto}"+(f",'02 Supplier Recovery Plan'!$A$221:$AE${lastsplit}" if lastsplit else ''),2:f"'03 BURNDOWN DATA'!$A$1:$O${lastreport}"}
 for name in names:
  if name.get('name')=='_xlnm.Print_Area' and int(name.get('localSheetId','-1')) in areas:name.text=areas[int(name.get('localSheetId'))]
 parts['xl/workbook.xml']=E.tostring(wb,encoding='UTF-8',xml_declaration=True)
 return book,{'chart_page':page,'pages':pages,'parts_on_page':sum(bool(b[f'DQ{r}'].value) for r in range(8,22)),'chart_start':str(start.date()),'chart_end':str(end.date())}

def export_pdf(workbook,workdir,soffice,profile,out,active_slots=14):
 import fitz
 dest=workdir/'pdf';dest.mkdir()
 arg='pdf:calc_pdf_Export:{"SinglePageSheets":{"type":"boolean","value":"true"}}'
 p=subprocess.run([soffice,f'-env:UserInstallation={profile.as_uri()}','--headless','--convert-to',arg,'--outdir',str(dest),str(workbook)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=300)
 path=dest/(workbook.stem+'.pdf')
 if p.returncode or not path.exists():raise RuntimeError('PDF export failed: '+p.stdout+' '+p.stderr)
 doc=fitz.open(path);page=doc[3];boxes=[]
 for draw in page.get_drawings():
  fill=draw.get('fill');r=draw['rect']
  if fill and max(fill)<.03 and 500<r.width<700 and 300<r.height<400:
   if not any(abs(r.x0-b.x0)<1 and abs(r.y0-b.y0)<1 for b in boxes):boxes.append(r)
 boxes=sorted(boxes,key=lambda r:(round(r.y0/5),r.x0))
 if len(boxes)!=14:raise RuntimeError(f'Expected 14 chart backgrounds, found {len(boxes)}. Workbook is saved; PDF layout needs review.')
 printed=fitz.open()
 for r in boxes[:active_slots]:
  new=printed.new_page(width=792,height=612);new.show_pdf_page(fitz.Rect(24,48,768,564),doc,3,clip=r,keep_proportion=True)
 printed.save(out);return path

def refresh(inputpath,outputpath,new_cycle=False,pdf=True,soffice=None):
 inputpath=Path(inputpath).resolve();outputpath=Path(outputpath).resolve()
 if inputpath==outputpath:raise ValueError('Use a new output filename; the input is never overwritten.')
 if outputpath.exists():raise FileExistsError(f'Output already exists: {outputpath}')
 soffice=soffice or shutil.which('soffice') or shutil.which('libreoffice')
 if not soffice:raise RuntimeError('LibreOffice is required. Install it and put soffice on PATH, or supply --soffice.')
 parts=loadparts(inputpath);raw=x.load_workbook(inputpath)
 if 'START HERE' in raw.sheetnames and 'NEW CYCLE TEMPLATE — NOT INITIALIZED' in str(raw['START HERE']['A4'].value) and not new_cycle:
  raise ValueError('This template has no frozen baseline. Use Start New Cycle.cmd / --new-cycle after loading and validating new OOR inputs.')
 if CONTROL not in raw.sheetnames:raise ValueError('This utility is for the maintained 210-line / 420-lot workbook.')
 if new_cycle:
  initialized=initialize_cycle(parts,raw)
  archive=outputpath.parent/'archive';archive.mkdir(parents=True,exist_ok=True);shutil.copy2(inputpath,archive/(inputpath.stem+'_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d_%H%M%S')+'.xlsx'))
 else:initialized=None
 with tempfile.TemporaryDirectory(prefix='stark-refresh-') as directory:
  work=Path(directory);profile=work/'profile';tmp=work/'input.xlsx';clear_caches(parts);saveparts(parts,tmp);controls=x.load_workbook(tmp);input_controls(controls)
  calculated,elapsed=calculate(tmp,work,soffice,profile);book,meta=finish(parts,calculated);outputpath.parent.mkdir(parents=True,exist_ok=True);saveparts(parts,outputpath)
  from harden_protection import harden
  harden(outputpath)
  from normalize_excel import normalize
  normalized=outputpath.with_suffix('.normalized.xlsx')
  normalize(outputpath,normalized)
  normalized.replace(outputpath)
  harden(outputpath)
  meta.update({'input':str(inputpath),'output':str(outputpath),'new_cycle_lines':initialized,'calculation_seconds':round(elapsed,3),'data_readiness':book[CONTROL]['B30'].value})
  if pdf:export_pdf(outputpath,work,soffice,profile,outputpath.with_name(outputpath.stem+'_Charts.pdf'),meta['parts_on_page'])
  outputpath.with_suffix('.refresh.json').write_text(json.dumps(meta,indent=2));return meta

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--input',required=True,type=Path);parser.add_argument('--output',required=True,type=Path);parser.add_argument('--new-cycle',action='store_true');parser.add_argument('--no-pdf',action='store_true');parser.add_argument('--soffice');a=parser.parse_args()
 try:print(json.dumps(refresh(a.input,a.output,a.new_cycle,not a.no_pdf,a.soffice),indent=2))
 except Exception as exc:parser.exit(1,f'Refresh stopped: {exc}\nInput workbook was not overwritten.\n')
