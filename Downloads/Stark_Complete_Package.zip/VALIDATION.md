# Usability update validation

Baseline: `Stark_PhaseII_VAL3110_Fixed.xlsx`, confirmed by the user to open and populate VAL-3110. A byte-identical checkpoint is retained separately before these changes.

## Implemented scope

1. Corrected Tab 3 chart description to parts remaining from actual shipments, Tab 2 transit heading to the Control tab/Stark, and INTITAL to INITIAL.
2. Added START HERE with Stark prepare/send and Supplier update/return checklists, five internal tab links and the opening selection. Existing five tabs retain their names/order for maintenance compatibility.
3. Tab 2 freezes at G11: columns A:F and header rows 1:10 remain visible.
5. Added a reference example: N50, Q10, S40, V5 gives Z35 and forecast35. Revised S is explicitly not reduced a second time after V.
6. Added warning-to-action guidance, return/release checks and the distinction between data validity and on-time delivery.
7. Added Stark-only Windows launchers and a cross-platform command-line launcher, dependency/setup instructions and return/version checklist. Suppliers need Excel only.
8. Added a separate clearly labeled simulation training workbook and a blank, uninitialized new-cycle input template. The template's simulation source/lot inputs, frozen records and cached results are removed; ordinary refresh is blocked until explicit new-cycle initialization. New-cycle initialization archives its input and captures a new validated baseline.

Recommendation 4 remains deferred. Existing input colors and calculated-field labels were not redesigned. Eighteen instructional cell notes were added to Tab 2 headers and Control settings/readiness cells; existing validations and protection remain in place.

## Checks passed

- Maintained workbook: every existing formula and business input unchanged; only the specified instruction strings changed. Existing conditional-formatting, validation extensions, filters and protection unchanged. All 14 chart XML parts and existing drawing parts are byte-identical to the confirmed working workbook, including VAL-3110.
- All three workbooks: ZIP integrity, XML parsing, unique relationship IDs, valid internal relationship targets, correct worksheet extension order, six worksheet names, START HERE active view, five navigation links and 18 notes.
- Rendered START HERE and existing workbook in LibreOffice; inspected guide text and layout. Corrected introductory text renders in full.
- Routine launcher executed successfully on a disposable copy, with full formula recalculation and 14-page chart PDF generation. Totals remain 21 PO lines / 42 populated lots / 2,520 baseline / 458 shipped / 2,062 remaining; 14 late lines remain. Data checks pass and chart refresh is CURRENT. VAL-3110 is present in the generated chart PDF. Notes, navigation and G11 freeze survive refresh.
- The blank template rejects ordinary refresh. Explicit new-cycle launcher tested with one separate 50-part test PO: it captures only the new baseline, clears supplier plan inputs and marks the output as a live initialized cycle. Readiness appropriately requires plan entry.
- A disposable initialized cycle was populated with N50/Q10/S40/V5 and valid dates. Routine launcher recalculation gives shipped15, still-to-ship35, revised forecast35, lot risk OK and DATA CHECKS PASS. Orange and purple both equal35 at AS OF.
- The refresh utility retains the sparse numeric-cache handling used for the VAL-3110 chart fix, omitting nonnumeric/error cached points while retaining their source formulas and indexes.

## Practical limits

Validation used Python, package/XML checks and LibreOffice. Native Excel rendering and Windows double-click/file-picker dialogs were not directly exercised in this Linux cloud environment. The actual launcher command path and complete refresh/new-cycle workflows were exercised. Stark must install the stated local dependencies before using launchers. Suppliers do not need them. This release does not change the existing model's capacity, business logic, chart design or protection scheme.

Machine-readable evidence is included in validation/. Test workbooks are excluded from the delivery package so that they cannot be mistaken for operating files.
