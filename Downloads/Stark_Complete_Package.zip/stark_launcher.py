"""Stark-only launcher; suppliers need Excel only. Always creates a new output."""
from pathlib import Path
import argparse, subprocess, sys, shutil

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--new-cycle',action='store_true');p.add_argument('--input',type=Path);p.add_argument('--output',type=Path);p.add_argument('--no-pdf',action='store_true');p.add_argument('--soffice')
 a=p.parse_args();root=None
 try:
  if not a.input or not a.output:
   import tkinter as tk
   from tkinter import filedialog
   root=tk.Tk();root.withdraw()
   source=a.input or filedialog.askopenfilename(title='Stark: select saved, CLOSED workbook',filetypes=[('Excel workbook','*.xlsx')])
   if not source:return 0
   a.input=Path(source)
   dest=a.output or filedialog.asksaveasfilename(title='Stark: choose a NEW output filename',initialdir=str(a.input.parent),initialfile=a.input.stem+('_Initialized' if a.new_cycle else '_Refreshed')+'.xlsx',defaultextension='.xlsx',filetypes=[('Excel workbook','*.xlsx')])
   if not dest:return 0
   a.output=Path(dest)
  if a.input.resolve()==a.output.resolve() or a.output.exists():raise ValueError('Choose a new output filename; existing files are never overwritten.')
  soffice=a.soffice or shutil.which('soffice') or shutil.which('libreoffice')
  if not soffice:
   for folder in [Path('C:/Program Files/LibreOffice/program'),Path('C:/Program Files (x86)/LibreOffice/program')]:
    candidate=folder/'soffice.exe'
    if candidate.exists():soffice=str(candidate);break
  if not soffice:raise RuntimeError('Stark setup requires LibreOffice. See README.md for installation and dependencies.')
  cmd=[sys.executable,str(Path(__file__).with_name('refresh_workbook.py')),'--input',str(a.input),'--output',str(a.output),'--soffice',soffice]
  if a.new_cycle:cmd.append('--new-cycle')
  if a.no_pdf:cmd.append('--no-pdf')
  print('Stark refresh running. Keep Excel closed for this file. This can take a few minutes.',flush=True)
  result=subprocess.run(cmd)
  if result.returncode:raise RuntimeError('Refresh stopped. Read the console message above. The input workbook was not overwritten. See README.md for setup and recovery steps.')
  message='Created: '+str(a.output)+'\nReview Control summary, exceptions, LATE / PLAN GAP actions, owners, chart coverage and the matching PDF before sending.'
  print(message)
  if root:
   from tkinter import messagebox
   messagebox.showinfo('Stark refresh complete',message)
  return 0
 except Exception as exc:
  print(str(exc),file=sys.stderr)
  if root:
   from tkinter import messagebox
   messagebox.showerror('Stark refresh stopped',str(exc))
  return 1
 finally:
  if root:root.destroy()
if __name__=='__main__':sys.exit(main())
