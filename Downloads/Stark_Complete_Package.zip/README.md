# Stark Phase II — first-time user package

Open **Stark_PhaseII_User_Guide.xlsx**. It opens on START HERE with Stark and Supplier checklists, links to the five existing tabs, the worked example, warning actions and release checks. The current fictional simulation, frozen baseline and all 14 charts are preserved. VAL-3110's working chart is retained.

## Files and roles

- **Stark_PhaseII_User_Guide.xlsx**: current reviewed workbook, with the authorized usability changes.
- **Stark_Training_Example.xlsx**: separate, clearly marked fictional practice copy. Do not send it as a live recovery plan.
- **Stark_New_Cycle_Template.xlsx**: blank new-cycle input shell. It has no frozen PO-line baseline and must be initialized by Stark before supplier use. It contains no simulation order/lot inputs or cached simulation results.
- **Refresh Stark Workbook.cmd**: Stark's routine refresh launcher. Double-click, select the saved/closed input, then choose a NEW output filename.
- **Start New Cycle.cmd**: Stark's new-cycle launcher. Use only after loading complete new OOR data and setting proposed baseline, AS OF and Monday chart start.
- The Python files and requirements support these launchers. Keep them together in the extracted package folder. Do not run tools from inside the ZIP.

Suppliers need Excel only. They edit and return the workbook; Stark maintains controls, initializes cycles, refreshes charts and issues the next version. No macros were added.

## One-time setup — Stark only

Install Python 3 with tkinter (included in the standard Windows installer) and LibreOffice. From the extracted package folder run:

    py -3 -m pip install -r requirements.txt

The launchers use `py -3` or `python`, and find LibreOffice on PATH or in the usual Windows Program Files folders. Setup is local to Stark's workstation. The cloud checks do not install anything on your computer. If the launchers fail, the console provides the error; the source workbook is never overwritten.

Command-line alternatives, including non-Windows workstations:

    python stark_launcher.py --input Returned.xlsx --output Supplier_ASOF_2026-11-04_v02.xlsx
    python stark_launcher.py --new-cycle --input NewCycleInputs.xlsx --output NewCycle_Initialized.xlsx

For a custom LibreOffice installation add `--soffice` with the full executable path. Add `--no-pdf` only if chart PDFs are not needed. Normal refresh creates a new workbook, matching `_Charts.pdf`, and `.refresh.json` log. Never reuse a PDF from an older workbook after changes.

## Start a live cycle — Stark only

1. Archive the previous cycle. Copy the blank **Stark_New_Cycle_Template.xlsx** to a new input filename.
2. Paste ONE supplier's complete new OOR values into **01 OOR PASTE!A9:X218**; clear unused input rows. Required data includes PO identity, positive open quantities, supplier name, units and buyer expedited on-dock need date. Capacity: 210 unique PO lines / 420 recovery lots.
3. Set **05 CONTROL & GUIDE!B9** proposed baseline, **B4** AS OF on/after baseline, **B5** confirmed calendar-day transit (currently 5), and **B6** Monday chart start within the supported cycle horizon. Page B8 starts at 1.
4. Save and close Excel. Run **Start New Cycle.cmd** and choose the new input and a NEW output name. It validates the source, archives its input, captures a fresh frozen baseline and clears supplier plan inputs in the output. An ordinary refresh is blocked on the uninitialized template; attempting initialization without valid inputs/settings also stops.
5. Review the new output. Original keys populate automatically. Missing plans will show REVIEW DATA / CONTROLS until valid supplier plans are entered. Complete/obtain those plans, save/close, then perform a routine refresh and release review.
6. Do not send the uninitialized blank template to a supplier. Do not paste new identities over the simulation while keeping the old baseline. A new cycle must use the explicit new-cycle process.

## Worked example — avoid double subtraction

For one 50-part lot: N=50; O=original promised on-dock date. Record the initial shipment Q=10 and its actual ship date R. Set the revised plan S=40 and promised on-dock date T. Record an additional shipment V=5 and actual ship date W. Keep Q=10 and S=40. Still to ship is N−Q−V=35; revised forecast quantity is S−V=35. Entering S=35 while retaining V=5 would subtract the additional shipment twice in the forecast.

Actual ship dates must be valid whole dates within the cycle and on/before AS OF. O/T are promised ON-DOCK dates. Never repeat a shipment in Q, V or a second lot. The instructional example is shown on START HERE without altering the simulation's actual lot records.

## Return / release review

Suppliers enter recovery actions in X and accountable owners in Y and return a new named version, for example `Supplier_ASOF_YYYY-MM-DD_vNN.xlsx`. Identify unresolved exceptions and late-plan actions in the return message. Stark reviews AS OF, source/lot exceptions, late/plan-gap actions and owners, runs refresh, checks CURRENT plus chart page/date-window coverage, and releases the refreshed workbook and matching PDF. **DATA CHECKS PASS means valid data; it does not mean an on-time plan.**

## Scope and validation

Implemented recommendations 1, 2, 3, 5, 6, 7 and 8 only. Recommendation 4 (new input-color legend and calculated-field relabeling) was deferred. Existing input colors, formula labels, chart formatting, calculations, conditional formatting, protection and business data remain unchanged in the maintained workbook. Tab 2 now freezes A:F and rows 1:10. Pop-up notes are legacy Excel cell notes: hover over marked headers/control cells, or use Review > Notes > Show All Notes.

The original five tabs retain their names/order for refresh compatibility. START HERE is appended and selected as the opening view. The maintained workbook's existing charts/drawings are byte-identical to the confirmed working version. Validation uses XML checks, Python and LibreOffice; Windows launcher dialogs and native Excel rendering are not directly tested here. See VALIDATION.md for test results.
