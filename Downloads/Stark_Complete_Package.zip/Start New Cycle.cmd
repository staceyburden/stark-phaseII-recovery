@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python "%~dp0stark_launcher.py" --new-cycle %*
) else (
  py -3 "%~dp0stark_launcher.py" --new-cycle %*
)
if errorlevel 1 echo See README.md for Stark setup. The input workbook is never overwritten.
pause
