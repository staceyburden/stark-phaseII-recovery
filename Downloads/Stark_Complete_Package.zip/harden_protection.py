from pathlib import Path
from lxml import etree as E
import zipfile,re,sys
N='http://schemas.openxmlformats.org/spreadsheetml/2006/main';q=lambda s:'{'+N+'}'+s

def harden(path):
 path=Path(path)
 with zipfile.ZipFile(path) as z:parts={n:z.read(n) for n in z.namelist()}
 styles=E.fromstring(parts['xl/styles.xml']);xfs=styles.find(q('cellXfs'));mapped={}
 def locked_style(old):
  p=xfs[old].find(q('protection'))
  if p is None or p.get('locked','1')!='0':return str(old)
  if old not in mapped:
   from copy import deepcopy
   new=deepcopy(xfs[old]);new.find(q('protection')).set('locked','1');new.set('applyProtection','1');mapped[old]=len(xfs);xfs.append(new)
  return str(mapped[old])
 for i in range(1,6):
  n=f'xl/worksheets/sheet{i}.xml';root=E.fromstring(parts[n])
  for c in root.iter(q('c')):
   addr=c.get('r');col=re.match('[A-Z]+',addr)[0];row=int(re.search(r'\d+',addr)[0])
   from openpyxl.utils.cell import column_index_from_string
   editable=(i==1 and 9<=row<=218 and column_index_from_string(col)<=24) or (i==2 and 11<=row<=430 and (col in ['M','N','O','Q','R','S','T','V','W','X','Y'] or (col=='J' and row>=221))) or (i==5 and addr in ['B4','B5','B6','B8','B9'])
   if c.find(q('f')) is not None:editable=False
   if not editable:c.set('s',locked_style(int(c.get('s','0'))))
  parts[n]=E.tostring(root,encoding='UTF-8',xml_declaration=True)
 xfs.set('count',str(len(xfs)));parts['xl/styles.xml']=E.tostring(styles,encoding='UTF-8',xml_declaration=True)

 # Keep package metadata consistent after adding the control sheet, tables and names.
 book=E.fromstring(parts['xl/workbook.xml']);sheetnames=[v.get('name') for v in book.find(q('sheets'))]
 if 'xl/sharedStrings.xml' in parts:
  ss=E.fromstring(parts['xl/sharedStrings.xml']);refs=sum(len(E.fromstring(v).findall('.//'+q('c')+'[@t="s"]')) for n,v in parts.items() if re.fullmatch(r'xl/worksheets/sheet\d+\.xml',n));ss.set('count',str(refs));ss.set('uniqueCount',str(len(ss.findall(q('si')))));parts['xl/sharedStrings.xml']=E.tostring(ss,encoding='UTF-8',xml_declaration=True)
 if 'docProps/app.xml' in parts:
  app=E.fromstring(parts['docProps/app.xml']);ap='{http://schemas.openxmlformats.org/officeDocument/2006/extended-properties}';vt='{http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes}';names=[]
  for n in book.find(q('definedNames')):
   name=n.get('name').replace('_xlnm.','')
   if 'localSheetId' in n.attrib:name="'"+sheetnames[int(n.get('localSheetId'))]+"'!"+name
   names.append(name)
  head=app.find(ap+'HeadingPairs');head[:]=[];vec=E.SubElement(head,vt+'vector',size='4',baseType='variant')
  for category,count in [('Worksheets',len(sheetnames)),('Named Ranges',len(names))]:
   E.SubElement(E.SubElement(vec,vt+'variant'),vt+'lpstr').text=category;E.SubElement(E.SubElement(vec,vt+'variant'),vt+'i4').text=str(count)
  titles=app.find(ap+'TitlesOfParts');titles[:]=[];vec=E.SubElement(titles,vt+'vector',size=str(len(sheetnames)+len(names)),baseType='lpstr')
  for name in sheetnames+names:E.SubElement(vec,vt+'lpstr').text=name
  parts['docProps/app.xml']=E.tostring(app,encoding='UTF-8',xml_declaration=True)

 temp=path.with_suffix('.protection.xlsx')
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
  for n,b in parts.items():z.writestr(n,b)
 temp.replace(path);return len(mapped)
if __name__=='__main__':
 for p in sys.argv[1:]:print(p,'locked style variants:',harden(p))
